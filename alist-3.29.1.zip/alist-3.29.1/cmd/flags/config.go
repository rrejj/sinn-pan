package flags

var (
	DataDir     string
	Debug       bool
	NoPrefix    bool
	Dev         bool
	ForceBinDir bool
	LogStd      bool
)
