package public

import "embed"

//go:embed dist
var Public embed.FS
